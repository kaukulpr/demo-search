this document can add the indexes to the elasticsearch
the method in index.js 

router.post('/insert",,,, is working now)
var elasticsearch = require('elasticsearch');
var express = require('express');

var elasticClient = new elasticsearch.Client({  
    host: 'localhost:9200',
    log: 'info'
});



//var resultArray = [];
resultArray = elasticClient.search({  
  index: 'subs',
  type: 'key',
  body: {
    query: {
        match: { 
           email: "hi" }
    },
  }

});
    console.log(resultArray);







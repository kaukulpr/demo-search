var express = require('express');
var router = express.Router();
var elasticsearch = require('elasticsearch');
var assert = require('assert');
//var mongo = require('mongodb');
var assert = require('assert');
var mailer = require("nodemailer");
//var smtpTransport = require('nodemailer-smtp-transport');
var xoauth2 = require('xoauth2');

/*var elasticClient = new elasticsearch.Client({  
    host: 'localhost:9200',
    log: 'info'
});*/

// Use Smtp Protocol to send Email
var smtpTransport = mailer.createTransport({
    service: "Gmail",
    auth: {
      xoauth2: xoauth2.createXOAuth2Generator({
        user: "kulpreetkaur006@gmail.com",
        pass: "NidhiArora09"
      })
    }
});

var mail = {
    from: "Kulpreet Kaur <kulpreetkaur006@gmail.com>",
    to: "kulpreetkaur06@gmail.com",
    subject: "Send Email Using Node.js",
    text: "Node.js New world for me",
    html: "<b>Node.js New world for me</b>"
}

smtpTransport.sendMail(mail, function(error, response){
    if(error){
        console.log(error);
    }else{
        console.log("Message sent: " + response.message);
    }

    smtpTransport.close();
});
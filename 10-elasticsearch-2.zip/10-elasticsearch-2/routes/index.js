var express = require('express');
var router = express.Router();
var elasticsearch = require('elasticsearch');
var assert = require('assert');
var mongo = require('mongodb');
var assert = require('assert');

//var url = 'mongodb://localhost:27017/test/';

var elasticClient = new elasticsearch.Client({  
    host: 'localhost:9200',
    log: 'info'
});

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index');
});
 
/*router.get('/get-data', function(req, res, next){
  var resultArray =  [];
  mongo.connect(url,  function(err, db){
    assert.equal(null, err);
    var cursor = db.collection('user-data').find();
    cursor.forEach(function(doc, err) {
      assert.equal(null,err);
      resultArray.push(doc);
    }, function() {
      db.close();
      res.render('index', {items: resultArray});
    });
  });
});*/

router.get('/get-data', function(req, res, next){
  var resultArray = [];

  elasticClient.indices.create({
    index:'user'  }
    ,function(err, resp, status)  {
      if(err)  {
        console.log(err)
      }
    }
    )
});


router.post('/insert', function(req, res, next){
  var item = {
    title: req.body.title,
    content: req.body.content,
    author: req.body.author
  };
  
mongo.connect(url, function(err,  db){
  assert.equal(null, err);
  db.collection('user-data').insertOne(item, function(err, result){
    assert.equal(null, err);
    console.log('item inserted');
    db.close();
});
});

  res.redirect('/');
});

router.post('/update', function(req, res, next){

});

router.post('/delete', function(req, res, next){

});


module.exports = router;

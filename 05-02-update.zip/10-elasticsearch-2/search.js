var express = require('express');
var router = express.Router();
var elasticsearch = require('elasticsearch');
var assert = require('assert');
//var mongo = require('mongodb');
var assert = require('assert');

var elasticClient = new elasticsearch.Client({  
    host: 'localhost:9200',
    log: 'info'
});

router.get('/subs', function(req, res, next){
   var resultArray = elasticClient.search({  
  index: 'subs',
  type: 'key',
  body: {
    query: {
        match: { email: "val1" }
    },
  }
},function (error, response,status) {
    if (error){
      console.log("search error: "+error)
    }
    else {
      console.log("--- Response ---");
      console.log(response);
      console.log("--- Hits ---");
      response.hits.hits.forEach(function(hit){
        console.log(hit);
      })
    }
}, function(){
    res.render('index', {items: resultArray});
});

});
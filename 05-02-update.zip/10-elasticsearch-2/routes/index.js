var express = require('express');
var router = express.Router();
var elasticsearch = require('elasticsearch');
var assert = require('assert');
//var mongo = require('mongodb');
var assert = require('assert');

var elasticClient = new elasticsearch.Client({  
    host: 'localhost:9200',
    log: 'info'
});

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index');
});
 
router.post('/insert-key', function(req, res, next){
elasticClient.index({
    index: 'subs', 
    type: 'key', 
    body: {
    keyword: req.body.keyword,
    frequency: req.body.freq,
    email: req.body.email
}
},function(err,resp,status) {
  console.log('Item inserted');
    console.log(resp);
    });
res.redirect('/');
});

router.post('/insert-topic', function(req, res, next){
elasticClient.index({
    index: 'subs', 
    type: 'topic', 
    body: {
    topic: req.body.topic,
    frequency: req.body.freq,
    email: req.body.email
}
},function(err,resp,status) {
    console.log(resp);
    });
res.redirect('/');
});

 //this code connects the app to mongo db
/*router.get('/get-data', function(req, res, next){
  var resultArray =  [];
  mongo.connect(url,  function(err, db){
    assert.equal(null, err);
    var cursor = db.collection('user-data').find();
    cursor.forEach(function(doc, err) {
      assert.equal(null,err);
      resultArray.push(doc);
    }, function() {
      db.close();
      res.render('index', {items: resultArray});
    });
  });
});*/


/*router.get('/subs', function(req, res, next){
  var search_email = req.body.search_email;
  var resultArray = [];
    resultArray = elasticClient.search({  
  index: 'subs',
  type: 'key',
  body: {
    query: {
        match: { email: search_email }
    },
  }
},function (error, response,status) {
    if (error){
      console.log("search error: "+error)
    }
    else {
      console.log("--- Response ---");
      console.log(response);
      console.log("--- Hits ---");
      response.hits.hits.forEach(function(hit){
        console.log(hit);
      })
    }
}, function(){
    res.render('index', {items: resultArray});
});

});*/

router.get('/get-data', function(req, res, next){
  var search_email = req.body.search_email;
  var resultArray = [];
    resultArray = elasticClient.search({  
  index: 'subs',
  type: 'key',
  body: {
    query: {
        match: { email: "test" }
    },
  }
},function (error, response,status) {
    if (error){
      console.log("search error: "+error)
    }
    else {
      console.log("--- Response ---");
      console.log(response);
      console.log("--- Hits ---");
      response.hits.hits.forEach(function(hit){
        console.log(hit);
      })
    }
}, function(){
    res.render('index', {items: resultArray});
});

});


router.post('/update', function(req, res, next){

});

router.post('/delete', function(req, res, next){
elasticClient.deleteByQuery({
        index: 'subs',
        type: 'key',
        body: {
           query: {
               match: { email: req.body.email }
           }
        }
    }, function (error, response) {
        console.log(response);
    });
    res.redirect('/');
});


module.exports = router;

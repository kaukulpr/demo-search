var elasticsearch = require('elasticsearch');

var elasticClient = new elasticsearch.Client({  
    host: 'localhost:9200',
    log: 'info'
});



elasticClient.deleteByQuery({
        index: 'sub',
        type: 'data',
        body: {
           query: {
               match: { email: 'oo' }
           }
        }
    }, function (error, response) {
        console.log(response);
    });
